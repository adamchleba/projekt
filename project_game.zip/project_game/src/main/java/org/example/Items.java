package org.example;

public enum Items {
    SWORD, SHIELD, APPLE, BREAD, GOLDEN_BREAD, ROCK


}
