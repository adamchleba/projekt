package org.example;

public enum Player_State {
    IDLE, IS_JUMPING, IS_WALKING, IS_RUNNING

}
