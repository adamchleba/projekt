package org.example;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Player {

    public ArrayList<Items> item;
    public Coords coords;
    public Image image;
    public int width;
    public int height;
    public final int PLAYER_STEPS = 5;

    public Player(int x, int y, String url) {
        ImageIcon ii = new ImageIcon(this.getClass().getResource("/" + url));
        this.image = ii.getImage();
        this.width = ii.getIconWidth();
        this.height = ii.getIconHeight();
        this.coords = new Coords(x,y);

        ArrayList<Items> item = new ArrayList<>();
    }

    public int getX() {
        return coords.x;
    }

    public int getY() {
        return coords.y;
    }

    public Image getImage() {
        return image;
    }

    public void moveLeft() {
        this.coords.x -= PLAYER_STEPS;
    }

    public void moveRight() {
        this.coords.x += PLAYER_STEPS;
    }

    public void moveUp() {
        this.coords.y -= PLAYER_STEPS;
    }

    public void moveDown() {
        this.coords.y += PLAYER_STEPS;
    }
}
