package org.example;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import static javax.swing.SwingConstants.LEFT;

public class Game {
    GameLogic logic;

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Game();
            }
        });
    }

    public Game() {
        logic = new GameLogic();
        GameGraphics gg = new GameGraphics(logic);
        logic.initialize();
        gg.render(logic);
        boolean isGameOver = false;

        gg.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:  // Handle left arrow key
                    case KeyEvent.VK_A:     // Handle 'A' key for left
                        logic.getPlayer().moveLeft();
                        break;
                    case KeyEvent.VK_RIGHT: // Handle right arrow key
                    case KeyEvent.VK_D:     // Handle 'D' key for right
                        logic.getPlayer().moveRight();
                        break;
                    case KeyEvent.VK_UP:    // Handle up arrow key
                    case KeyEvent.VK_W:     // Handle 'W' key for up
                        logic.getPlayer().moveUp();
                        break;
                    case KeyEvent.VK_DOWN:  // Handle down arrow key
                    case KeyEvent.VK_S:     // Handle 'S' key for down
                        logic.getPlayer().moveDown();
                        break;
                }
            }
            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
    }
}