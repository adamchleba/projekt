package org.example;

import javax.swing.*;
import java.awt.*;

public class GameGraphics extends JFrame {
        Draw draw;
        GameLogic logic;

        public GameGraphics(GameLogic logic) throws HeadlessException {
            this.logic = logic;
            this.draw = new Draw();

            setSize(1080, 720);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setVisible(true);
            setTitle("Bread Hunt");

            add(draw);
        }

        public void render(GameLogic logic) {
            this.logic = logic;
            repaint();
        }

        public class Draw extends JPanel {
            @Override
            protected void paintComponent(Graphics g) {
                ImageIcon image = new ImageIcon("/src/main/resources/playertest.png");
                g.drawImage(image.getImage(), 300,300,null);
                super.paintComponent(g);  // Volání nadřazené metody paintComponent je důležité pro správné vykreslení pozadí JPanelu.
                if (logic.getPlayer() != null && logic.getPlayer().getImage() != null) {
                    g.drawImage(logic.getPlayer().getImage(),
                            logic.getPlayer().getX(),
                            logic.getPlayer().getY(),
                            this);  // Tady 'this' je ImageObserver, a protože JPanel implementuje ImageObserver rozhraní, můžeme ho přímo použít.
                }
                else{
                    System.out.println("sum ting is null");
                }
            }
        }
    }